# Spherical Channel Network

Paper: [Spherical Channels for Modeling Atomic Interactions](https://arxiv.org/abs/2206.14331)]

C. Lawrence Zitnick, Abhishek Das, Adeesh Kolluru, Janice Lan, Muhammed Shuaibi, Anuroop Sriram, Zachary Ulissi, Brandon Wood

To run the model, you need to install the [E3NN library](https://github.com/e3nn/e3nn/).
